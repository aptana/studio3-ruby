package org.jrubyparser.ast;

/**
 * Marker interface for nodes invisible to IDE consumers
 */
public interface InvisibleNode {}
